<template>
    <div id="smartTown">
        智能小镇管理系统
    </div>
</template>
<script>
export default {
    name: 'smartTown',
    data(){
        return{

        }
    }
}
</script>
<style scoped>

</style>

